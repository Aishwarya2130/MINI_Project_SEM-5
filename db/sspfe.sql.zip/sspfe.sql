-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 24, 2023 at 10:06 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sspfe`
--

-- --------------------------------------------------------

--
-- Table structure for table `assigned_subject`
--

CREATE TABLE `assigned_subject` (
  `as_id` int(100) NOT NULL auto_increment,
  `sub_id` int(100) NOT NULL,
  `s_id` int(100) NOT NULL,
  `a_date` varchar(100) NOT NULL,
  PRIMARY KEY  (`as_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `assigned_subject`
--

INSERT INTO `assigned_subject` (`as_id`, `sub_id`, `s_id`, `a_date`) VALUES
(14, 3, 2, '20-04-2023'),
(15, 5, 1, '20-04-2023'),
(16, 7, 3, '20-04-2023'),
(17, 4, 4, '20-04-2023'),
(18, 7, 5, '20-04-2023'),
(19, 6, 7, '20-04-2023');

-- --------------------------------------------------------

--
-- Table structure for table `department_details`
--

CREATE TABLE `department_details` (
  `dept_id` int(100) NOT NULL auto_increment,
  `dept_name` varchar(100) NOT NULL,
  PRIMARY KEY  (`dept_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `department_details`
--

INSERT INTO `department_details` (`dept_id`, `dept_name`) VALUES
(1, 'Electronics Communications'),
(2, 'Computer Science'),
(3, 'Civil'),
(4, 'AutoMobile'),
(5, 'Mech'),
(6, 'IC'),
(7, 'MTT');

-- --------------------------------------------------------

--
-- Table structure for table `document_details`
--

CREATE TABLE `document_details` (
  `d_id` int(100) NOT NULL auto_increment,
  `st_id` int(100) NOT NULL,
  `d_name` varchar(100) NOT NULL,
  `d_type` varchar(100) NOT NULL,
  `r_date` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`d_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `document_details`
--

INSERT INTO `document_details` (`d_id`, `st_id`, `d_name`, `d_type`, `r_date`, `status`) VALUES
(2, 10, 'Adhar Card', '-', '20-04-2023', 'Submited'),
(3, 11, 'PanCard', '-', '20-04-2023', 'Submited'),
(4, 12, 'MarksCard', '-', '20-04-2023', 'Submited');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `f_id` int(100) NOT NULL auto_increment,
  `f_from` varchar(100) NOT NULL,
  `f_to` varchar(100) NOT NULL,
  `feedback` varchar(100) NOT NULL,
  `rating` varchar(5) NOT NULL,
  `fdate` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`f_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`f_id`, `f_from`, `f_to`, `feedback`, `rating`, `fdate`, `status`) VALUES
(1, '10', '4', 'Best', '3', '20-04-2023', '-'),
(2, '11', '2', 'good', '5', '20-04-2023', '-'),
(3, '12', '5', 'Best', '5', '20-04-2023', '-'),
(4, '11', '4', 'Testing', '-', '20-04-2023', 'New');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `u_type` varchar(100) NOT NULL,
  `s_question` varchar(100) NOT NULL,
  `s_answer` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--


-- --------------------------------------------------------

--
-- Table structure for table `query`
--

CREATE TABLE `query` (
  `q_id` int(100) NOT NULL auto_increment,
  `q_from` varchar(100) NOT NULL,
  `q_to` varchar(100) NOT NULL,
  `query` varchar(100) NOT NULL,
  `a_date` varchar(100) NOT NULL,
  `reply` varchar(100) NOT NULL,
  `r_date` varchar(100) NOT NULL,
  PRIMARY KEY  (`q_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `query`
--

INSERT INTO `query` (`q_id`, `q_from`, `q_to`, `query`, `a_date`, `reply`, `r_date`) VALUES
(1, '10', '2', 'yenill', '24-04-2023', '-', '24-04-2023'),
(2, '11', '1', 'Nothing', '20-04-2023', '-', '20-04-2023'),
(3, '12', '6', 'nthng', '20-04-2023', '-', '20-04-2023');

-- --------------------------------------------------------

--
-- Table structure for table `staff_details`
--

CREATE TABLE `staff_details` (
  `s_id` int(100) NOT NULL auto_increment,
  `dept_id` int(100) NOT NULL,
  `s_fname` varchar(100) NOT NULL,
  `s_lname` varchar(100) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `city` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  PRIMARY KEY  (`s_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `staff_details`
--

INSERT INTO `staff_details` (`s_id`, `dept_id`, `s_fname`, `s_lname`, `mobile`, `city`, `email`, `photo`) VALUES
(1, 20, 'Sita', 'N', '9234018217', 'Benglur', 'Sita@gmail.com', '-'),
(2, 1, 'Ram', 'N', '8912456371', 'Ramnagar', 'Ram@gmail.com', '-'),
(3, 3, 'Laxman', 'N', '8712540162', 'Kolar', 'Laxman@gmail.com', '-'),
(4, 4, 'Mahadev', 'S', '8941576809', 'Kailas', 'Mahadev@gmail.com', '-'),
(5, 5, 'Parvati', 'S', '8712543891', 'Himalay', 'Parvati@gmail.com', '-'),
(6, 6, 'Ganesh', 'S', '9871237651', 'Lalbaug', 'Ganesh@gmail.com', '-');

-- --------------------------------------------------------

--
-- Table structure for table `student_details`
--

CREATE TABLE `student_details` (
  `st_id` int(100) NOT NULL auto_increment,
  `dept_id` int(100) NOT NULL,
  `st_regno` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `mob` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  PRIMARY KEY  (`st_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `student_details`
--

INSERT INTO `student_details` (`st_id`, `dept_id`, `st_regno`, `fname`, `mname`, `lname`, `mother_name`, `dob`, `mob`, `email`, `city`, `photo`) VALUES
(10, 2, '414CS20029', 'Shru', 'A', 'Nagave', 'P', '2001-08-30', '9361795002', 'shruti@gmail.com', 'BND', '-'),
(11, 4, '414CS20013', 'Aishwarya', 'p', 'Huddar', 'J', '2004-12-30', '7892850146', 'aishwarya1@gmail.com', 'Mumbai', '-'),
(12, 1, '414CS20031', 'Tanishka ', 'R', 'Nagarali', 'V', '2004-09-17', '8123270749', 'Tanishka@gmail.com', 'snk', '-');

-- --------------------------------------------------------

--
-- Table structure for table `stud_details`
--

CREATE TABLE `stud_details` (
  `sid` int(100) NOT NULL auto_increment,
  `fname` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `stud_details`
--

INSERT INTO `stud_details` (`sid`, `fname`, `status`) VALUES
(1, 'Tanishka', 'Done'),
(2, 'Aishwarya B', 'Done'),
(3, 'Aishwarya H', 'Done'),
(4, 'Kavya', 'Done'),
(5, 'Shruti', 'Done'),
(6, 'Ashwini', 'Done'),
(7, 'Laxmi', 'Done'),
(8, 'Tanuja', 'Done'),
(9, 'Chaitra', 'Done'),
(10, 'Sneha', 'Done'),
(11, 'Shahid', 'Done'),
(12, 'Harsh', 'Done'),
(13, 'Abhishek', 'Done'),
(14, 'Vaibhav', 'Done'),
(15, 'Vivek', 'Done'),
(16, 'Aashish', 'Done'),
(17, 'Gopi', 'Done'),
(18, 'Sachin', ' pending'),
(19, 'Adarsh', 'Done'),
(20, 'Yash', 'Done'),
(21, 'Shivam', 'absent'),
(22, 'Dharmraj', 'incomplete'),
(23, 'Pramod', 'incomplete'),
(24, 'Jagdish', 'incomplete'),
(25, 'Vinayak', 'absent'),
(26, 'Shreya', 'Done'),
(27, 'Aishwarya ', 'Done'),
(28, 'Siddika', 'Done'),
(29, 'Zeenat', 'Done'),
(30, 'Bhakti', 'Done'),
(31, 'Pramila', 'Done'),
(32, 'Madhureena', 'Done'),
(33, 'Shivam k', 'Done');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `sub_id` int(100) NOT NULL auto_increment,
  `sub_name` varchar(100) NOT NULL,
  `sub_code` varchar(100) NOT NULL,
  PRIMARY KEY  (`sub_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sub_id`, `sub_name`, `sub_code`) VALUES
(1, 'CHMA', '20CS1'),
(2, 'DBMS', '20CS2'),
(3, 'OS', '20CS3'),
(4, 'Python', '20CS4'),
(5, 'JAVA', '20CS5'),
(6, 'SE', '20CS6'),
(7, 'Maths', '20CS7'),
(8, 'FC', '20CS8');
